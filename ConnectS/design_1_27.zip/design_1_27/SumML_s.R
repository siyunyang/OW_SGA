
source("PStrim.R")
load.lib<-c("ranger", "glmnet", "gbm", "twang", "BART", "mboost", "crossmatch","rms","tidyverse",
            "rpart", "mvtnorm", "xgboost", "caret", "parallel", "doParallel")
install.lib<-load.lib[!load.lib %in% installed.packages()]
for(lib in install.lib) install.packages(lib,dependencies=TRUE, repos = "http://cran.us.r-project.org")
sapply(load.lib, require, character=TRUE)
############################################################
#generate the balance assessment statistics using formula only and
# glm for propensity model
############################################################


SumML_s <- function(ps.formula, subgroup=NULL, trtgrp=NULL, data=NULL, weight= "overlap", method="LASSO", delta=0){
  
  ## Arguments:
  # ps.formula(formula for non-subgroup effect only) an object of class \code{\link{formula}} (or one that can be coerced to that class): a symbolic description of the propensity score model to be fitted. Additional details of model specification are given under "Details". This argument is optional if \code{ps.estimate} is not \code{NULL}.
  # subgroup name of subgroup variables of data
  # trtgrp an optional character defining the "treated" population for estimating the average treatment effect among the treated (ATT). Only necessary if \code{weight = "treated"}. This option can also be used to specify the treatment (in a two-treatment setting) when a vector argument is supplied for \code{ps.estimate}. Default value is the last group in the alphebatic order.
  # data an optional data frame containing the variables in the propensity score model. If not found in data, the variables are taken from \code{environment(formula)}.
  # weight a character or vector of characters including the types of weights to be used. \code{"IPW"} specifies the inverse probability weights for estimating the average treatment effect among the combined population (ATE). \code{"treated"} specifies the weights for estimating the average treatment effect among the treated (ATT). \code{"overlap"} specifies the (generalized) overlap weights for estimating the average treatment effect among the overlap population (ATO), or population at clinical equipoise. \code{"matching"} specifies the matching weights for estimating the average treatment effect among the matched population (ATM). \code{"entropy"} specifies the entropy weights for the average treatment effect of entropy weighted population (ATEN). Default is \code{"overlap"}.
  # method a character or vector of characters including the types of propensity score model to be used.\code{"logistic"} specifies the logistic regression. \code{"spline"} specifies the splined logistic regression using R package rms.
  # delta trimming threshold for estimated (generalized) propensity scores. Should be no larger than 1 / number of treatment groups. Default is 0, corresponding to no trimming.
  #'
  
  ## Returns: 
  #  trtgrp: treatment group if using att
  #  propensity: estimated propensity
  #  ASD: estimated asd
  #  vif
  #  ess:eff.sample.size
  #  splot=splot

  #####################################################################
  
  
  #extract the subgroups
  if(is.null(subgroup)){
    stop("No subgroup specified")
  }
  
  #convert the formula into character
  if(typeof(ps.formula)!="character"){
    ps.formula<-Reduce(paste0,deparse(ps.formula))
  }
  ps.formula<-gsub(" ","",ps.formula)
  
  splitform<-unlist(strsplit(ps.formula,'~'))
  zname<-splitform[1]
  
  covname<-unlist(strsplit(splitform[2],'\\+'))
  
    
  #trim the data
  if(delta>0){
    tmp<-PStrim(data=data,ps.formula=ps.formula,delta=delta)
    data<-tmp[[1]]
    trim_sum<-tmp[[2]]
  }
  
  
  #extract z
  data[,zname]<-as.factor(data[,zname])
  categoryz<-sort(unique(unlist(data[zname])))
  if (length(categoryz)==1) stop("Treatment variable needs to have more than 1 category.","\n")
  
  #number of categories and dataframe size
  z<-as.numeric(factor(unlist(data[zname])))
  data["zindex"]<-z
  ncate<-length(categoryz)
  n<-dim(data)[1]
  
  #creat a dictionary for the original and recoded values in Z. The final output is based on original group names
  dic<-rep(-1,ncate)
  for (i in 1:ncate) dic[i]<-as.character(unique(unlist(data[zname])[which(data$zindex==i)]))
  
  #pick out the treatment group if treated is specified
  if (!is.null(trtgrp)) trt<-which(dic==trtgrp)
  
  
  #subgroup matrix
  submatrix<-as.matrix(data[,subgroup])

  if(is.null(colnames(submatrix))){
    colnames(submatrix)<-paste0('sub',1:dim(submatrix)[2])
  }
 
  #estimate ps
  if(method =='LASSO'){
    # full-interaction matrix
    ps.form2<-paste(ps.formula,paste0(subgroup, collapse="+"),sep="+")
    
    for (h in 1:length(subgroup)){
      for (k in 1:length(covname)){
        ps.form2 = paste(ps.form2,paste(subgroup[h],"*",covname[k],sep=""),sep="+") 
      }
    }
    
    fullmatrix <- model.matrix(as.formula(ps.form2), data)
    
    
  pscore_mod3 <- cv.glmnet(y=factor(z), x=fullmatrix, penalty.factor=c(rep(0,(min(grep("\\:",colnames(fullmatrix)))-1) ), rep(1, sum(grepl('\\:',colnames(fullmatrix))))), family="binomial", maxit=50000)
  nonzero_coef <- rownames(coef(pscore_mod3, s='lambda.min'))[which(coef(pscore_mod3, s='lambda.min')!=0)][-1]
  if(length(nonzero_coef)==0){
    print("no coef")
    pscore_mod4 <- glm(factor(z)~1, family="binomial")
  }else{ 
    fit <- glm(factor(z)~., data=data.frame(fullmatrix[,nonzero_coef]), family="binomial")
    e.h <- fit$fitted.values
    e.h <- cbind(1-e.h,e.h)
    colnames(e.h)<-categoryz  }
  }
  else if (method =='spline'){
    library(rms)
    fit <- lrm(formula = as.formula(ps.formula), data=data, x=TRUE, y =TRUE) 
    e.h <- predict(fit, type="fitted.ind")
    e.h <- cbind(1-e.h,e.h)
    colnames(e.h)<-categoryz
    }
  # estimate weight
  if(weight =='overlap'){
    tilt.h<-(1/apply(1/e.h,1,sum))
    allwt<-(1/e.h)*tilt.h
    wt<-rep(0,n)
    for(i in 1:ncate){
      wt[z==i]<-allwt[z==i,i]
    }
  }
  
  else if (weight == 'IPW'){
    tilt.h<-rep(1,n)
    allwt<-1/e.h
    wt<-rep(0,n)
    #wt1<-rep(0,n)
    for(i in 1:ncate){
      wt[z==i]<-allwt[z==i,i]
      #wt1[z==i]<-allwt[z==i,i]/sum(allwt[z==i,i])}
    }
  }
  else if (weight == 'treated'){
    if (is.null(trtgrp)){
      tilt.h<-e.h[,ncate]
      allwt<-tilt.h/e.h
      wt<-rep(0,n)
      #wt1<-rep(0,n)
      for(i in 1:ncate){
        wt[z==i]<-allwt[z==i,i]
        #wt1[z==i]<-allwt[z==i,i]/sum(allwt[z==i,i])
      }
    }else{
        cattrt<-(trtgrp==sort(z,decreasing = TRUE)[1])+1
        tilt.h<-e.h[,cattrt]
        allwt<-tilt.h/e.h
        wt<-rep(0,n)
        for(i in 1:ncate){
          wt[z==i]<-allwt[z==i,i]
      } 
    }
  }
  
  #also generate the baseline weight
  wt_bs<-rep(1,n)
  
  # the design matrix for balance check
  ps.form <- str_remove(ps.formula, "rcs\\(" )
  ps.form <- str_remove(ps.form, "\\)" )
  covM<-as.data.frame(model.matrix(formula(ps.form),data))
  covM<-as.matrix(covM)
  if (ncol(covM)>1){
    #drop intercept
    if(unique(covM[,1])==1) {
    covM<-covM[,-1,drop=F]
    }
  }
  
  
  
  # the asd function to calculate the balance
  abs_stand_diff <- function(x_j, z, w){
    # Inputs:
    # x_j: a vecor of the covariate
    # z: a vector of treatment indicator
    # w: a vector of weights
    if (anyNA(w)) {return (NA)} else
      x_j <- as.numeric(x_j)
    
    absdiff <- abs(sum(x_j*z*w)/sum(z*w) - sum(x_j*(1-z)*w)/sum((1-z)*w))
    tstat <- absdiff/sqrt((var(x_j[which(z==1)])+var(x_j[which(z==0)]))/2)
    return (tstat)
  }
  
  
  # Access the overall and subgroup asd
  tm <- list()
  for (k in 1:ncol(submatrix)){
    tm[[k]]<- table(submatrix[,k])
  }
  # number of subgroup levels by each subgrouping variable
  
  # subgroup levels
  nlevels <- c(unlist(lapply(tm,length)))

  nsubg <- c(unlist(tm))
  subg.name <- names(nsubg)
  
  subcovnames <- colnames(submatrix)

  subg.name <- paste0(rep(subcovnames,nlevels),'=',subg.name)
  
  names(tm) <- subcovnames
  
  names(nsubg)<-subg.name
  
  overall_asd <- apply(covM, 2, abs_stand_diff, z-1, wt)
  
  overall_asd_bs <- apply(covM, 2, abs_stand_diff, z-1, wt_bs)
  
  #Calculate balance per subgroup across covariates
  groups_asd <- c()
  groups_asd_bs <- c()
  names_col <- c()
  
  for(r in 1:ncol(submatrix)){ 
    level.name <- unique(submatrix[,r])
    for(g in 1:length(unique(submatrix[,r]))){
      find_g <- which(submatrix[,r]==level.name[g])
      g_asd <- apply(covM[find_g, ], 2, abs_stand_diff, (z-1)[find_g], wt[find_g])
      groups_asd <- cbind(groups_asd, g_asd)
      
      g_asd_bs<-apply(covM[find_g, ], 2, abs_stand_diff, (z-1)[find_g], wt_bs[find_g])
      groups_asd_bs<- cbind(groups_asd_bs, g_asd_bs)
      
    }
  }
  
  colnames(groups_asd) <-subg.name
  colnames(groups_asd_bs) <-subg.name
  
  
  ASD <- cbind(Overall=overall_asd,groups_asd)

  ASD_bs <- cbind(Overall=overall_asd_bs,groups_asd_bs)
  
    
  # subgroup sample size including overall
  nsubg <- c(length(z), nsubg)
  
  
  # number of subgroups
  nv <- length(nsubg)
    
  #number of covariate
  ncov <- dim(covM)[2]+1
  
  
  
  # calculate VIF, Effective sample size  
  # weights approximation

  #Matrix for effective sample size
  eff.sample.size<-matrix(-1,nrow=ncate*nv,ncol=(length(weight)))
  colnames(eff.sample.size)<-c(weight)

  rownames(eff.sample.size)<-c(t(outer(paste0(colnames(ASD),'_treatment_'),dic,paste0)))

  eff.sample.size_bs<-eff.sample.size
  
  #function to calculate eff and vif
  eff_vif_cal<-function(wt=1,ztmp){
    eff_est<-c()
    nj<-0
    for (j in 1:ncate){
      eff_est<-c(eff_est,sum(wt*(ztmp==j))^2/sum((wt*(ztmp==j))^2))
      nj<-nj+1/sum(ztmp==1)
    }
    vif_est<-c(1/nj*sum(1/eff_est))
    return(c(eff_est,vif_est))
  }
  
  vif <- c()
  vif_bs<-c()
  
  #overall value
  overall_val<-eff_vif_cal(wt,z)
  vif<-c(vif,overall_val[ncate+1])
  eff.sample.size[1:2,]<-overall_val[1:ncate]
    
  overall_val_bs<-eff_vif_cal(wt_bs,z)
  vif_bs<-c(vif_bs,overall_val_bs[ncate+1])
  eff.sample.size_bs[1:2,]<-overall_val_bs[1:ncate]
  
  countertmp<-2
  for(r in 1:ncol(submatrix)){ 
    level.name <- sort(unique(submatrix[,r]))
    for(g in 1:length(unique(submatrix[,r]))){
      find_g <- which(submatrix[,r]==level.name[g])
      
      overall_tmp<-eff_vif_cal(wt[find_g],z[find_g])
      vif<-c(vif,overall_tmp[ncate+1])
      eff.sample.size[(1+countertmp):(2+countertmp),]<-overall_tmp[1:ncate]
      
      overall_tmp_bs<-eff_vif_cal(wt_bs[find_g],z[find_g])
      vif_bs<-c(vif_bs,overall_tmp_bs[ncate+1])
      eff.sample.size_bs[(1+countertmp):(2+countertmp),]<-overall_tmp_bs[1:ncate]
      
      countertmp<-countertmp+2
      
    }
  }  

  names(vif)<-colnames(ASD)
  names(vif_bs)<-colnames(ASD)
  
  
  output<-list(trtgrp=trtgrp, propensity=e.h, ps.weights= weight, ASD=ASD, ASD_bs=ASD_bs, vif=vif,vif_bs=vif_bs, nsubg=nsubg, ess=eff.sample.size,ess_bs=eff.sample.size_bs)
  if (delta>0) output[["trim"]]<-trim_sum
  
  class(output)<-'SumStat_s'
  output
  
}


