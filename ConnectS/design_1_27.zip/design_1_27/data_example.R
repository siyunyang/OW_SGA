

# source functions
# set working directory
source("SumStat_s.R")
source("SumML_s.R")
source("print_Sumstat_s.R")
source("Plot_SumStat_s.R")
#########################################
######## Illustration 1 #################

data <- read.csv("sample_data.csv")[,-1]
# specify subgroups
subg <- data[,c(2,3,4,20,21)]


# specify general covariates
ps.form<-paste("Treatment~",paste0("X",1:20,collapse = "+"))
# arbitrary ps model
ps.form1<-paste(ps.form,"+X1*X7+X1*X8+X2*X7")
# full interaction ps model
ps.form2 <-paste(ps.form, paste(paste(paste("X", 1:18, sep=""), "*X19", sep=""), collapse=" + "), paste(paste(paste("X", 1:18, sep=""), "*X20", sep=""), collapse=" + "),sep="+")


subgroup<-paste0('X',c(1,2,3,4, 5, 19,20))



### example call
p <- SumStat_s(ps.formula = ps.form1, subgroup = subgroup, data=data, weight=c("overlap"), delta = 0.01)
p

# default print all main effect variables
plot(p)
plot(p,base = T)


# can specify certain variables by index or variable names
plot(p,varlist = c(1,2,3))
plot(p,varlist = c("X1","X2","X7"))
plot(p,varlist = c("X1","X2","X7"),base = T)



# ATO
p <- SumStat_s(ps.formula = ps.form2, subgroup = subgroup, data=data, weight=c("overlap"))
p

plot(p)

# ATE
p <- SumStat_s(ps.formula = ps.form2, subgroup = subgroup, data=data, weight=c("IPW"))
p

plot(p)

# ATT
p <- SumStat_s(ps.formula = ps.form2, subgroup = subgroup, data=data, weight=c("treated"))
p

plot(p)


# ATT
p <- SumStat_s(ps.formula = ps.form2, subgroup = subgroup, data=data, weight=c("treated"), trtgrp = 0)
p

plot(p)


#post-LASSO
# specify general covariates
ps.form<-paste("Treatment~",paste0("X",6:18,collapse = "+"))
subgroup<-paste0('X',c(1,2,3,4, 5, 19,20))
p <- SumML_s(ps.formula= ps.form, subgroup, trtgrp=NULL, data, weight= "overlap", method="LASSO", delta=0)
plot(p)



#rcs
ps.form <- "Treatment~ X1+X2+X3+X4+X5+X6+X7+X8+rcs(X9)+X10+X11+X12+X13+X14+X15+X16+X17+X18+X19+X20"
subgroup<-paste0('X',c(1,2,3,4, 5, 19,20))

p <- SumML_s(ps.formula= ps.form, subgroup, trtgrp=NULL, data, weight= "overlap", method="spline", delta=0)
plot(p)

